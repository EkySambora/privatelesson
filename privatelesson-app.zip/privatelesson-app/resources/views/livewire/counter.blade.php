<div>
    {{-- Because she competes with no one, no one can compete with her. --}}
    <button wire:click="decrement">-</button>
    <span> {{ $count }}</span>
    <button wire:click="increment">+</button>
</div>
