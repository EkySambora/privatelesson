<?php return array (
  'counter' => 'App\\Http\\Livewire\\Counter',
  'show-posts' => 'App\\Http\\Livewire\\ShowPosts',
);