<div>
    
    <button wire:click="decrement">-</button>
    <span> <?php echo e($count); ?></span>
    <button wire:click="increment">+</button>
</div>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/example-app/resources/views/livewire/counter.blade.php ENDPATH**/ ?>