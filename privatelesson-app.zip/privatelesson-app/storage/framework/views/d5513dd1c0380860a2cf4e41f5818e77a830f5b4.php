<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <?php echo \Livewire\Livewire::styles(); ?>

</head>
<body>
<p>register page <?php echo e($data); ?></p>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('counter')->html();
} elseif ($_instance->childHasBeenRendered('nVGAeJN')) {
    $componentId = $_instance->getRenderedChildComponentId('nVGAeJN');
    $componentTag = $_instance->getRenderedChildComponentTagName('nVGAeJN');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('nVGAeJN');
} else {
    $response = \Livewire\Livewire::mount('counter');
    $html = $response->html();
    $_instance->logRenderedChild('nVGAeJN', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php echo \Livewire\Livewire::scripts(); ?>

</body>
</html><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/example-app/resources/views/auth/register.blade.php ENDPATH**/ ?>